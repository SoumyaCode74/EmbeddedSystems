# Embedded-C
Repository for udemy Embedded-C course
